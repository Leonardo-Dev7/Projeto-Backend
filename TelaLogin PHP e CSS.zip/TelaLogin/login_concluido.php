<?php
session_start();
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$cpfInformado = preg_replace('/\D/', '', $_POST['cpf'] ?? '');

if (empty($email) || empty($senha)) {
    header('Location: login.php?error=' . urlencode('Por favor, preencha e-mail e senha.'));
    exit;
}

$stmt = $conexao->prepare('SELECT id, nome, cpf, senha_hash FROM usuarios WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado && $resultado->num_rows === 1) {
    $usuario = $resultado->fetch_assoc();
    $cpfBanco = preg_replace('/\D/', '', $usuario['cpf'] ?? '');
    $cpfOk = empty($cpfInformado) || ($cpfBanco === $cpfInformado);
    if ($cpfOk && password_verify($senha, $usuario['senha_hash'])) {
        $_SESSION['usuario_id'] = (int)$usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        header('Location: dashboard.php');
        exit;
    }
}

header('Location: login.php?error=' . urlencode('Credenciais inválidas. Verifique seus dados.'));
exit;
