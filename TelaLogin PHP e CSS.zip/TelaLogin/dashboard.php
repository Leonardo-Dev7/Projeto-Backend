<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
$nome = htmlspecialchars($_SESSION['usuario_nome']);
$backgroundImage = "img/Background.png";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard</title>
  <link rel="stylesheet" href="Style.css">
  <style>
    body { background-image:url('<?php echo $backgroundImage;?>'); background-size:cover; background-position:center; font-family:'Strawberry Shortcake NEW',sans-serif; color:#B82924; }
    .wrap { min-height:100vh; display:flex; align-items:center; justify-content:center; padding:40px; }
    .card { background:rgba(255,255,255,0.92); padding:28px; border-radius:16px; text-align:center; max-width:560px; width:90%; box-shadow:0 8px 24px rgba(0,0,0,0.12); }
    .btn { display:inline-block; padding:10px 16px; border-radius:14px; border:3px solid #B82924; background:#ffe4eb; color:#EE435E; text-decoration:none; font-weight:bold; margin-top:16px;}
    @media (max-width:480px) { .card { padding:18px; } }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>Bem-vindo(a), <?php echo $nome; ?>!</h1>
      <p>Você está logado com sucesso.</p>
      <a href="logout.php" class="btn">Sair</a>
    </div>
  </div>
</body>
</html>
